export { default } from './scrapeservice.js';
export { scrapeHomepage } from './scrapeservice.js';
